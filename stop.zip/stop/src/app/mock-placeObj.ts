import { Place } from './domain/place';

export const placeObj: Place = { 
restNumber:1
};