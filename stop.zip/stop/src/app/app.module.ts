import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { StopIndex4buttonsComponent } from './stop/stop-index-4buttons/stop-index-4buttons.component';
import { AppRoutingModule } from './app-routing.module';
import { CheckTheRestComponent } from './stop/check-the-rest/check-the-rest.component';
import { HttpModule } from '@angular/http';
import { StopService } from './service/stop.service';
import { ApiService } from './service/api.service';
import { ParkCarComponent } from './stop/park-car/park-car.component';
import { LoginComponent } from './stop/login/login.component';
import { GetCarComponent } from './stop/get-car/get-car.component';
import { FormsModule }   from '@angular/forms';
import { ControlCenterComponent } from './stop/control-center/control-center.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NotFoundComponent } from './stop/not-found/not-found.component';
import { ParkService } from './service/park.service';
import { AuthService } from './service/auth.service';
import { SearchService } from './service/search.service';
import { GetService } from './service/get.service';
import { SuccessComponent } from './stop/success/success.component';
import { FailComponent } from './stop/fail/fail.component';
import { CarDetailComponent } from './stop/car-detail/car-detail.component';
import { PayOffComponent } from './stop/pay-off/pay-off.component';
import { SelectComponent } from './stop/select/select.component';





@NgModule({
  declarations: [
    AppComponent,
    StopIndex4buttonsComponent,
    CheckTheRestComponent,
    ParkCarComponent,
    LoginComponent,
    GetCarComponent,
    ControlCenterComponent,
    NotFoundComponent,
    SuccessComponent,
    FailComponent,
    CarDetailComponent,
    PayOffComponent,
    SelectComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    ApiService,
    StopService,
    ParkService,
    AuthService,
    SearchService,
    GetService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
