export class Place {
restNumber:number;
}
