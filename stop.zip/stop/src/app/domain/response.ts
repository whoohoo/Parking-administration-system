export class Response {
reply: boolean;
}
