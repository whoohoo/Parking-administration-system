export class Manager {
userName:string;
passWord:string;
}
