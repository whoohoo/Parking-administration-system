export class Car {
id:string;
begin:string;
end:string;
cost:number;
}
