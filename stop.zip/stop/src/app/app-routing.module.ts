import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StopIndex4buttonsComponent }      from './stop/stop-index-4buttons/stop-index-4buttons.component';
import {  CheckTheRestComponent }      from './stop/check-the-rest/check-the-rest.component';
import {  ParkCarComponent }      from './stop/park-car/park-car.component';
import {  LoginComponent }      from './stop/login/login.component';
import {  GetCarComponent }      from './stop/get-car/get-car.component';
import { NotFoundComponent } from './stop/not-found/not-found.component';
import { ControlCenterComponent } from './stop/control-center/control-center.component';


const routes: Routes = [
  { path: '', redirectTo: '/stop', pathMatch: 'full' },
  { path: 'stop',component:  StopIndex4buttonsComponent },
  { path: 'check',component:  CheckTheRestComponent },
  { path: 'park',component:  ParkCarComponent },
  { path: 'login',component:  LoginComponent },
  { path: 'get',component:  GetCarComponent },
  {path: 'center', component: ControlCenterComponent},
   {path: '**', component: NotFoundComponent},
 
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}