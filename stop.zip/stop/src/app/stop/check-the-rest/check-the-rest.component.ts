import { Component, OnInit } from '@angular/core';
import { Place } from '../../domain/place';
import { StopService } from '../../service/stop.service';
import { AppRoutingModule } from '../../app-routing.module';

@Component({
  selector: 'app-check-the-rest',
  templateUrl: './check-the-rest.component.html',
  styleUrls: ['./check-the-rest.component.css']
})
export class CheckTheRestComponent implements OnInit {

  constructor(private stopService: StopService) { }

  placeObj: Place;
  isLoading : boolean = false;

  ngOnInit() {
    this.getRestNumber();
    this.isLoading = false;
  }

  getRestNumber(){
   this.isLoading = true;
   this.stopService.getRestNumber().then(placeObj => {
    this.placeObj = placeObj;
    console.log(this.placeObj);
  });
  }

}
