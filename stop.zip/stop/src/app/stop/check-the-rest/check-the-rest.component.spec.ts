import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckTheRestComponent } from './check-the-rest.component';

describe('CheckTheRestComponent', () => {
  let component: CheckTheRestComponent;
  let fixture: ComponentFixture<CheckTheRestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckTheRestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckTheRestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
