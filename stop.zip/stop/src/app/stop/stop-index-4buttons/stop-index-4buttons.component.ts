import { Component, OnInit } from '@angular/core';
import { AppRoutingModule } from '../../app-routing.module';

@Component({
  selector: 'app-stop-index-4buttons',
  templateUrl: './stop-index-4buttons.component.html',
  styleUrls: ['./stop-index-4buttons.component.css']
})
export class StopIndex4buttonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
