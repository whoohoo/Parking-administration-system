import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StopIndex4buttonsComponent } from './stop-index-4buttons.component';

describe('StopIndex4buttonsComponent', () => {
  let component: StopIndex4buttonsComponent;
  let fixture: ComponentFixture<StopIndex4buttonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StopIndex4buttonsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StopIndex4buttonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
