import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayOffComponent } from './pay-off.component';

describe('PayOffComponent', () => {
  let component: PayOffComponent;
  let fixture: ComponentFixture<PayOffComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayOffComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayOffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
