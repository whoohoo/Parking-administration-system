import { Component, OnInit } from '@angular/core';
import { Car } from '../../domain/car';
import { Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pay-off',
  templateUrl: './pay-off.component.html',
  styleUrls: ['./pay-off.component.css']
})
export class PayOffComponent implements OnInit {

  constructor(private router: Router) { }

   @Input() car: Car;

  ngOnInit() {
  }

    cancel():void{
  this.router.navigate(['/stop']);
  }

}
