import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Car } from '../../domain/car';
import { GetService } from '../../service/get.service';

@Component({
  selector: 'app-get-car',
  templateUrl: './get-car.component.html',
  styleUrls: ['./get-car.component.css']
})
export class GetCarComponent implements OnInit {

  constructor(private router: Router, private getService: GetService) { }

  ngOnInit() {
  }

    newCar: Car = {
    id: '',
    begin:'',
    end:'',
    cost:0
  }

  newCar1: Car = {
   id: '',
    begin:'',
    end:'',
    cost:0
  }

   car:Car;

  
   s:string;

  confirm():void{
  console.log(this.newCar.id+"!");
  //将this.newCar.id传给后台
   this.getService.makeGet(this.newCar.id).then(newCar1 =>  {
    this.newCar1 = newCar1;
    console.log(this.newCar1);

  if(this.newCar1.begin==""){
  
  alert("取车失败，请检查车牌号是否正确！");

    }else{
    this.s = "1";
this.car = this.newCar1;
    }

  });

  }


  cancel():void{
  this.router.navigate(['/stop']);
  }


}
