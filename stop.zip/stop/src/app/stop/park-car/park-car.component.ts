import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Car } from '../../domain/car';
import { Response } from '../../domain/response';
import { ParkService } from '../../service/park.service';


@Component({
  selector: 'app-park-car',
  templateUrl: './park-car.component.html',
  styleUrls: ['./park-car.component.css'],

  })

export class ParkCarComponent implements OnInit {

  constructor(private router: Router, private parkService: ParkService) { }


  ngOnInit() {
  }

  newCar: Car = {
    id: '',
    begin:'',
    end:'',
    cost:0
  }

  park:Response;
  s:string;
  f:string;

  confirm():void{
  console.log(this.newCar.id);
  //将this.newCar.id传给后台,并得到true or false的回复。
  this.parkService.makePark(this.newCar.id).then(park =>  {
    this.park = park;  
    console.log(this.park);
  console.log(this.park.reply);
  if(this.park.reply){
  this.s = '1';
  console.log(this.s);
  }else{
  this.f = '1';
  console.log(this.f);
  }

  });


  }

  cancel():void{
  this.router.navigate(['/stop']);
  }

}
