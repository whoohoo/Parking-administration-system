import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Car } from '../../domain/car';
import { SearchService } from '../../service/search.service';

@Component({
  selector: 'app-control-center',
  templateUrl: './control-center.component.html',
  styleUrls: ['./control-center.component.css']
})
export class ControlCenterComponent implements OnInit {

  constructor(private router: Router, private searchService: SearchService) { }

  ngOnInit() {
 
  }

     newCar: Car = {
    id: '',
    begin:'',
    end:'',
    cost:0
  }

  newCar1: Car = {
   id: '',
    begin:'',
    end:'',
    cost:0
  }

  car:Car;
  f:string;

  confirm():void{
  console.log(this.newCar.id+"!");
  //将this.newCar.id传给后台
   this.searchService.search(this.newCar.id).then(newCar1 =>  {
    this.newCar1 = newCar1;
    console.log(this.newCar1);
    if(this.newCar1.begin==""){
    this.f = '1';
    console.log(this.f);

    }else{
this.car = this.newCar1;
    }
  });

  }


  cancel():void{
  this.router.navigate(['/stop']);
  }

}
