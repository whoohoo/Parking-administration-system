import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Manager } from '../../domain/manager';
import { Response } from '../../domain/response';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],

})
export class LoginComponent implements OnInit {

  constructor(private router: Router,private authService : AuthService) { }

  ngOnInit() {
  }

 manager:Manager ={
 userName: '',
 passWord: ''

 }

   s:string;
  f:string;

 login:Response;

  confirm():void{
  console.log(this.manager.userName);
  console.log(this.manager.passWord);
  //将用户名和密码传给后台
this.authService.Login(this.manager.userName,this.manager.passWord).then(login =>  {
    this.login = login;
    console.log(this.login.reply);

if(this.login.reply){
  this.s = '1';
  console.log(this.s);
  setTimeout(() => {
            this.router.navigate(['/center']);
        }, 2000);
        
  }else{
  this.f = '1';
  alert("登陆失败，请检查用户名和密码！")
  console.log(this.f);
  }

 
  });
  }


  cancel():void{

  this.router.navigate(['/stop']);

  }



}
