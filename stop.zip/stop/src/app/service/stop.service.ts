import { Injectable } from '@angular/core';
import { Place } from '../domain/place';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { ApiService } from './api.service';

@Injectable()
export class StopService {
  private api_url ;
  private headers ;

  constructor(private http: Http, private apiService: ApiService) { 
        this.api_url = apiService.getUrl()+'/check';
        this.headers = apiService.getHeaders();
  }

  getRestNumber():Promise<Place>{
   const url = `${this.api_url}`;
    return this.http
            .get(url)
            .toPromise()
            .then(res => res.json() as Place)
            .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); 
        return Promise.reject(error.message || error);
    }


}
