
import { Headers } from '@angular/http';


export class ApiService {

   getUrl(): string {
        return 'http://172.23.237.237:8080';
    }
   getHeaders(): Headers {
        return new Headers({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'});
    }

}
